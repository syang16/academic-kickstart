import sys
import os
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt

class evalM_imbalanced(object):
    def __init__(self, precision, recall, fpr, tpr, F_w=5, ROC_w=[0.2, 0.36, 0.488, 0.5904, 3.3616], Separations=[0.2, 0.4, 0.6, 0.8]):
        self.precision = precision
        self.recall = recall
        self.fpr = fpr
        self.tpr = tpr
        self.F_w = F_w
        self.ROC_w = ROC_w
        self.Separations = Separations
        
    def  calculate(self):

        wght_F = (1 + self.F_w * self.F_w ) * self.precision * self.recall / (self.recall + self.F_w * self.F_w * self.precision)
        print('F' + str(self.F_w) +' score: ' + str(wght_F))
            
        n_points = len(self.fpr)
        
        i = 0
        j = 0
        bin_ind = []
        while (i < n_points and j < len(self.Separations)):
            if self.tpr[i] <= self.Separations[j]:
                i += 1
            else:
                bin_ind += [i]
                j += 1
    
        area_prev = 0
        Wght_AUC = 0
        for j in range(len(self.Separations)):
            bound = list(self.tpr[:bin_ind[j]]) + [self.Separations[j]] * (n_points - bin_ind[j])
            area = metrics.auc(self.fpr, bound)
            Wght_AUC += self.ROC_w[j] * (area - area_prev)
            area_prev = area

        Wght_AUC += self.ROC_w[-1] * (auc_roc - area)
            
        print ('Weighted AUC-ROC: ' + str(Wght_AUC))
        
if __name__ == "__main__":
    
    method_name, arg_strs = sys.argv[0], sys.argv[1:] 
    kwargs = {}
    for s in arg_strs:
        if s.count('=') == 1:
            key, value = s.split('=', 1)
        else:
            key, value = None, s
        if key:
            kwargs[key] = value
    
    if 'testPath' not in kwargs.keys() or not os.path.exists(kwargs['testPath']+'/aucTemp.txt'):
        print ("ERROR: Please specify the correct path to the test data.")
        sys.exit()
        
    try:
        fileR = open(kwargs['testPath']+'/aucTemp.txt', "r")
        y_label = []
        y_pred = []
        for line in fileR:
            y_label += [int(line.split(" ")[1].strip('\n'))]
            y_pred += [float(line.split(" ")[0])]
              
        ll = metrics.log_loss(y_label, y_pred)
        print('Log loss: ' + str(ll))
        
        precisions, recalls, thresholds = metrics.precision_recall_curve(y_label, y_pred)

        for ind, threshold in enumerate(thresholds):
            if threshold > 0.5:
                break
        ind = ind - 1 if ( ind > 0  and ind < len(thresholds)) else ind
        precision = precisions[ind]
        recall = recalls[ind]
        print('Precision: ' + str(precision))
        print('Recall: ' + str(recall))
        
        fpr, tpr, _ = metrics.roc_curve(y_label, y_pred)
        auc_roc = metrics.auc(fpr, tpr)
        print('AUC-ROC: ' + str(auc_roc))
        
        auc_pr = metrics.average_precision_score(y_label, y_pred)
        print('AUC_PR: ' + str(auc_pr))
              
        f1 = 2 * precision * recall / (recall + precision)
        print('F1 score: ' + str(f1))
        
        if 'Imbalanced' in kwargs.keys() and kwargs['Imbalanced']:
            evalM_imbalanced_obj = evalM_imbalanced(precision, recall, fpr, tpr)
            evalM_imbalanced_obj.calculate()
        
    except:
        print ("Evaluation Metrics are not calculated correctly.")
        
        
        