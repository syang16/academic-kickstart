import os

print("This is an example of running RCTBN with a sample trajectory dataset from Drug effect network.")


os.system('java -cp boostingCTBN.jar edu.wisc.cs.Boosting.RDN.RunBoostedRDN -target Jointpain -l -train DrugData/train/ -i -test DrugData/test/ -negPosRatio -1 -aucJarPath .')

print("Evaluation of Relational CTBN: ")

os.system('python Calc_evalM.py testPath=DrugData/test/AUC/')