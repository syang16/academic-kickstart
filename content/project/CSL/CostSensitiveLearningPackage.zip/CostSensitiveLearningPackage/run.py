import os

print("This is an example of running this package with a UCI machine learning dataset--Heart Disease.")

os.system("python ConvertStandardData.py filename=SampleData/HD.csv target=num Discretize='trestbps':[120],'age':['value',5],'chol':[200],'thalach':['quantile',5],'oldpeak':['value',3]")

os.system('java -cp SoftBoosting.jar edu.wisc.cs.Boosting.RDN.RunBoostedRDN -target num -l -train SampleData/OutputDataForSoft-RFGB/HD/train/ -i -test SampleData/OutputDataForSoft-RFGB/HD/test/ -modelSuffix hard -negPosRatio -1 -alpha 0 -beta 0 -aucJarPath .')

os.system('java -cp SoftBoosting.jar edu.wisc.cs.Boosting.RDN.RunBoostedRDN -target num -l -train SampleData/OutputDataForSoft-RFGB/HD/train/ -i -test SampleData/OutputDataForSoft-RFGB/HD/test/ -modelSuffix soft -negPosRatio -1 -alpha 1 -beta -2 -aucJarPath .')

print("Evaluation of hard RFGB: ")

os.system('python Calc_evalM.py testPath=SampleData/OutputDataForSoft-RFGB/HD/test/AUC/hard Imbalanced=True')

print("Evaluation of soft RFGB with alpha=1, beta=-2: ")

os.system('python Calc_evalM.py testPath=SampleData/OutputDataForSoft-RFGB/HD/test/AUC/soft Imbalanced=True')

print("As the results shown, cost-sensitive RFGB can greatly improve the recall with similar or better overall performance, such as F measure or AUC-PR.")
