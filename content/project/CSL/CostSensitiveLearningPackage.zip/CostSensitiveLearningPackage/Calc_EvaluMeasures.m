function [ Wght_AUC, F_beta ] = Calc_EvaluMeasures (fname )
% function to calculate evaluation measurements for class-imbalance problems
% input: predicted results from probabilistic models
% output: weighted AUC-ROC, F-beta measure
% Author: Shuo Yang 
% Date: 1/30/2014
%
fid=fopen(fname);
C=textscan(fid,'%s %s');
output(:,1)=str2double(C{1,1});
output(:,2)=str2double(C{1,2});
fclose(fid);

[X, Y, T, AUC] = perfcurve(output(:,2),output(:,1),1);
if AUC==0
    Wght_AUC=0;
else
    [X_temp,m1,n1] = unique(X,'first');
    [X_temp,m2,n2] = unique(X,'last');
    
    for i=1:length(m1)
        Y_temp(i) = mean(Y(m1(i):m2(i)));
    end
    total_points=10000;
    xi=linspace(0,1,total_points);
    yi=interp1(X_temp,Y_temp,xi);
    
    ind=zeros(1,4);
    for i=1:length(xi)-1
        if yi(i)<=0.2 && yi(i+1)>0.2
            ind(1)=i;
        else if yi(i)<=0.4 && yi(i+1)>0.4
                ind(2)= i;
            else if yi(i)<=0.6 && yi(i+1)>0.6
                    ind(3)=i;
                else if yi(i)<=0.8 && yi(i+1)>0.8
                        ind(4)=i;
                    end
                end
            end
        end
    end
    
    if ind(1)==0
        bound(1,:)=yi;
    else
        bound(1,1:ind(1))=yi(1:ind(1));
        bound(1,ind(1)+1:total_points)=0.2*ones(1, total_points-ind(1));
    end
    
    if ind(2)==0
        bound(2,:)=yi;
    else
        bound(2,1:ind(2))=yi(1:ind(2));
        bound(2,ind(2)+1:total_points)=0.4*ones(1, total_points-ind(2));
    end
    
    if ind(3)==0
        bound(3,:)=yi;
    else
        bound(3,1:ind(3))=yi(1:ind(3));
        bound(3,ind(3)+1:total_points)=0.6*ones(1, total_points-ind(3));
    end
    
    if ind(4)==0
        bound(4,:)=yi;
    else
        bound(4,1:ind(4))=yi(1:ind(4));
        bound(4,ind(4)+1:total_points)=0.8*ones(1, total_points-ind(4));
    end
    
    weighted_AUC(1)=trapz(xi,bound(1,:));
    weighted_AUC(2)=trapz(xi,bound(2,:))-trapz(xi,bound(1,:));
    weighted_AUC(3)=trapz(xi,bound(3,:))-trapz(xi,bound(2,:));
    weighted_AUC(4)=trapz(xi,bound(4,:))-trapz(xi,bound(3,:));
    weighted_AUC(5)=trapz(xi,yi)-trapz(xi,bound(4,:));
    
    
    weight=[0.2, 0.36, 0.488, 0.5904, 3.3616];
    
    Wght_AUC=0;
    for i=1:5
        Wght_AUC = Wght_AUC+weight(i)*weighted_AUC(i);
    end
end

PR_beta = 5;
threshold = 0.5;

N_fn=0;
N_pp=0;
N_tp=0;
N_tn=0;
N_fp=0;
for i=1:length(output(:,2))
    if output(i,1)<=threshold
        if output(i,2)==1
            N_fn = N_fn+1;
        else
            N_tn = N_tn+1;
        end
    end
    if output(i,1)>= threshold
        N_pp = N_pp+1;
        if output(i,2)==1
            N_tp = N_tp+1;
        else
            N_fp = N_fp+1;
        end
    end
end

recall = N_tp/(N_fn+N_tp);

if N_pp==0
    Precision = 1;
else
    Precision = N_tp/N_pp;
end
if Precision==0 && recall==0
    F_beta= 0;
else
    F_beta = (1+PR_beta^2)*Precision*recall/(recall+PR_beta^2*Precision);
end
end

