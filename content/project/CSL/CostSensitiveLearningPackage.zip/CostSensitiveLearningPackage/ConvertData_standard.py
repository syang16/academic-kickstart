
''' This python function can convert the flat table from standard machine learning problems 
into the input files that Soft-Margin RFGB can take.
Author: Shuo Yang Date: 5/2014'''

import pandas as pd
import os
import shutil
import numpy as np
import sys
import random
import re

def Write_files(data, filename, Target_f, TestRatio):
    if os.path.dirname(filename):
        foldername = os.path.dirname(filename)
    else:
        foldername = '.'
    
    foldername+= '/OutputDataForSoft-RFGB'
    fname = os.path.basename(filename).split('.')[0]
    foldername+= '/' + fname

    if os.path.exists( foldername ):
        shutil.rmtree(foldername)    
    try:
        os.makedirs(foldername+ '/test')
        os.makedirs(foldername+ '/train')
    except OSError as exc: # Guard against race condition
        if exc.errno != errno.EEXIST:
            raise
    
    
    with open( foldername + '/' + fname + '_bk.txt', "a") as fwbk:
        fwbk.write ('queryPred: ' + Target_f + '/1.\n')
        fwbk.write ('mode: ' + Target_f + '(+id).\n')
        for col in data.columns:
            if col != Target_f:
                fwbk.write('mode: ' + col + '(+id, #' + col + ').\n')
    fwbk.close()
     
    with open( foldername + '/train/train_bk.txt', "a") as fwbk:
        fwbk.write ('import: "../' + fname + '_bk.txt".' )
    fwbk.close()   
    with open( foldername + '/test/test_bk.txt', "a") as fwbk:
        fwbk.write ('import: "../' + fname + '_bk.txt".' )
    fwbk.close()


    for ind in range(len(data)):
        seed = random.random()
        if seed <= float(TestRatio):
            subfoldername = foldername+ '/test'
            fname = 'test'
        else:
            subfoldername = foldername+ '/train'
            fname = 'train'

        if data.loc[ind, Target_f] == 0:
            with open( subfoldername + '/' +  fname + "_neg.txt", "a") as fwneg:
                fwneg.write(Target_f + '(' + str(ind) + ').\n')
        else:
            with open( subfoldername + '/' +  fname + "_pos.txt", "a") as fwpos:
                fwpos.write(Target_f + '(' + str(ind) + ').\n')
        
        with open( subfoldername + '/' +  fname + "_facts.txt", "a") as fwfact: 
            for col in data.columns:
                if col != Target_f:
                    if not np.isnan(data.loc[ind, col]):
                        fwfact.write(col + '(' + str(ind) + ',' + str(data.loc[ind, col]) + ').\n')

    fwneg.close()
    fwpos.close()
    fwfact.close()
    
def Data_Discretize(data, Discretize):
    for feature in Discretize.keys():
        if 'quantile' in Discretize[feature]:
            nbin = float(Discretize[feature][1])
            quant = 1.0/nbin
            factore = pd.qcut(data[feature], np.arange(0, 1+quant, quant) )
        else:
            if 'value' in Discretize[feature]:
                nbin = float(Discretize[feature][1])
                factore = pd.cut(data[feature], nbin)
            else:
                threholds = [float(item) for item in Discretize[feature]]
                nbin = len(threholds) + 1
                threholds.insert(0,-np.inf)
                threholds.append(np.inf)
                factore = pd.cut(data[feature], threholds)
                
        factore = factore.cat.rename_categories(range(int(nbin)))
        data[feature] = factore
                
    return data        
    
def ConvertData_standard(**kwargs):
    print (kwargs)

    data = pd.read_csv(kwargs['filename'], header=0)
    data =  data.convert_objects(convert_numeric=True)
    data.columns = [re.sub('[^A-Za-z0-9]+', '', i) for i in data.columns ]
    if 'Discretize' in kwargs.keys():
        data = Data_Discretize(data, kwargs['Discretize'])
                
    Write_files(data, kwargs['filename'], kwargs['target'], kwargs['TestRatio'])
            
if __name__ == "__main__":
    
    method_name, arg_strs = sys.argv[0], sys.argv[1:] 
    kwargs = {}
    for s in arg_strs:
        if s.count('=') == 1:
            key, value = s.split('=', 1)
        else:
            key, value = None, s
        if key:
            kwargs[key] = value
            
    if 'filename' not in kwargs.keys():
        print ("ERROR: Please specify the path and file name of the data.")
        sys.exit()
    else:
        if 'target' not in kwargs.keys():
            print ("ERROR: Please specify the target variable.")
            sys.exit()

    if 'TestRatio' not in kwargs.keys():
        kwargs['TestRatio'] = -1
    if 'Discretize' not in kwargs.keys():
        ConvertData_standard(filename=kwargs['filename'], target=kwargs['target'], TestRatio =kwargs['TestRatio'])
    else:
        Discretizelist = kwargs['Discretize'].split('],')

        Discretize_dic = {}
        for item in Discretizelist:
            key, value = item.split(':[', 1)
            Discretize_dic[key] = value.strip(']').split(',')
       
        ConvertData_standard(filename=kwargs['filename'], target=kwargs['target'], TestRatio =kwargs['TestRatio'], Discretize= Discretize_dic)
 

