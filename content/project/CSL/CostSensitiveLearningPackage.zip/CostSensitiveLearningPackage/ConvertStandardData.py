
''' This python script can convert the flat table from standard machine learning problems 
into the input files that Soft-Margin RFGB can take.
Author: Shuo Yang Date: 5/2020'''

import pandas as pd
import os
import shutil
import numpy as np
import sys
import random
import re

class convertData(object):
    def __init__(self, data, target, outputPath, dataName, Discretize, lableThreshold, TestRatio):
        self.data = data
        self.target = target
        self.outputPath = outputPath
        self.dataName = dataName
        self.Discretize = Discretize
        self.lableThreshold = lableThreshold
        self.TestRatio = TestRatio
        
    def Data_Discretize(self):
        
        for feature in self.Discretize.keys():
            if 'quantile' in self.Discretize[feature]:
                nbin = float(self.Discretize[feature][1])
                quant = 1.0/nbin
                factore = pd.qcut(self.data[feature], np.arange(0, 1+quant, quant) )
            else:
                if 'value' in self.Discretize[feature]:
                    nbin = float(self.Discretize[feature][1])
                    factore = pd.cut(self.data[feature], nbin)
                else:
                    threholds = [float(item) for item in self.Discretize[feature]]
                    nbin = len(threholds) + 1
                    threholds.insert(0,-np.inf)
                    threholds.append(np.inf)
                    factore = pd.cut(self.data[feature], threholds)
                
            factore = factore.cat.rename_categories(range(int(nbin)))
            self.data[feature] = factore
            
    def Write_files(self):

        if os.path.exists( self.outputPath):
            shutil.rmtree(self.outputPath)    
        try:
            os.makedirs(self.outputPath+ '/test')
            os.makedirs(self.outputPath+ '/train')
        except OSError as exc: # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise   
    
        with open( self.outputPath + '/' + self.dataName + '_bk.txt', "a") as fwbk:
            fwbk.write ('queryPred: ' + self.target + '/1.\n')
            fwbk.write ('mode: ' + self.target + '(+id).\n')
            for col in self.data.columns:
                if col != self.target:
                    fwbk.write('mode: ' + col + '(+id, #' + col + ').\n')
        fwbk.close()
     
        with open( self.outputPath + '/train/train_bk.txt', "a") as fwbk:
            fwbk.write ('import: "../' + self.dataName + '_bk.txt".' )
        fwbk.close()   
        with open( self.outputPath + '/test/test_bk.txt', "a") as fwbk:
            fwbk.write ('import: "../' + self.dataName + '_bk.txt".' )
        fwbk.close()


        for ind in range(len(self.data)):
            seed = random.random()
            if seed <= float(self.TestRatio):
                subfoldername = self.outputPath+ '/test'
                fname = 'test'
            else:
                subfoldername = self.outputPath+ '/train'
                fname = 'train'

            if self.data.loc[ind, self.target] <= self.lableThreshold:
                with open( subfoldername + '/' +  fname + "_neg.txt", "a") as fwneg:
                    fwneg.write(self.target + '(' + str(ind) + ').\n')
            else:
                with open( subfoldername + '/' +  fname + "_pos.txt", "a") as fwpos:
                    fwpos.write(self.target + '(' + str(ind) + ').\n')
        
            with open( subfoldername + '/' +  fname + "_facts.txt", "a") as fwfact: 
                for col in self.data.columns:
                    if col != self.target:
                        if not np.isnan(self.data.loc[ind, col]):
                            fwfact.write(col + '(' + str(ind) + ',' + str(self.data.loc[ind, col]) + ').\n')

        fwneg.close()
        fwpos.close()
        fwfact.close()
                
    def run(self):
        self.data =  self.data.apply(pd.to_numeric, errors='coerce')
        self.data.columns = [re.sub('[^A-Za-z0-9]+', '', i) for i in self.data.columns ]
        
        if self.Discretize:
            self.Data_Discretize()
            
        self.Write_files()

            
if __name__ == "__main__":
    
    labelThreshold_default = 0
    testRatio_default = 0.2
    
    method_name, arg_strs = sys.argv[0], sys.argv[1:] 
    kwargs = {}
    for s in arg_strs:
        if s.count('=') == 1:
            key, value = s.split('=', 1)
        else:
            key, value = None, s
        if key:
            kwargs[key] = value
            
    if 'filename' not in kwargs.keys():
        print ("ERROR: Please specify the path and file name of the data.")
        sys.exit()
        
    if 'target' not in kwargs.keys():
        print ("ERROR: Please specify the target variable.")
        sys.exit()

    if os.path.exists(kwargs['filename']):
        
        filename = kwargs['filename']
        data = pd.read_csv(filename, header=0)
        
        if os.path.dirname(filename):
            outputPath = os.path.dirname(filename)
        else:
            outputPath = '.'
    
        outputPath+= '/OutputDataForSoft-RFGB'
        dataName = os.path.basename(filename).split('.')[0]
        outputPath+= '/' + dataName
        
        Discretize_dic = {}
        if 'Discretize' in kwargs.keys():
            Discretizelist = kwargs['Discretize'].split('],')
            for item in Discretizelist:
                key, value = item.split(':[', 1)
                Discretize_dic[key] = value.strip(']').split(',')
                
        labelThreshold = labelThreshold_default if 'labelThreshold' not in kwargs.keys() else float(kwargs['labelThreshold'])
        testRatio = testRatio_default if 'TestRatio' not in kwargs.keys() else float(kwargs['TestRatio'])
               
        convertData_obj = convertData(data, kwargs['target'], outputPath, dataName, Discretize_dic, labelThreshold, testRatio)
        convertData_obj.run()
        
    else:
        print("Converting data failed... Please double check if input file exists.")
        
        
